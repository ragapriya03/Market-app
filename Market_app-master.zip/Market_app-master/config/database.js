module.exports = {
    database: 'mongodb://localhost/coracart'
}